/********************* C SOURCE CODE FOR UNINFORMED AND INFORMED SEARCH *********************
 * The program performs uninformed and informed search for a given set of inputs
 * to determine shortest path from an origin city to a destination city.
 * Uninformed search is done using Uniform Cost Search algorithm using priority queues.
 * Informed search is done using A-star algorithm and takes heuristic inputs.
 * The program uses number of command line arguments provided to choose between
 * uninformed search and informed search to perform. If no heuristic input file is provided,
 * the program performs uninformed search using three arguments provided from command line.
 * When a heuristic input file is provided as fourth argument, the program performs
 * informed cost search.
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_CITY_LENGTH 200 // Assume a city's name will be less than 200 characters

// Added to check if every dynamically allocated memory is freed
int numMallocs = 0;
int numFreed = 0;

/* Structure of an edge
 * An edge has a source city, a destination
 * city, and the length (in km) between the
 * source and destination cities.
 */
typedef struct edge
{
    char source[MAX_CITY_LENGTH]; // source city name
    char destination[MAX_CITY_LENGTH]; // destination city name
    double length; // length between the two cities
    struct edge *next; // pointer to the next edge
}edge;

/* Structure of a node that will be inserted
 * and popped from priority queue.
 */
typedef struct node
{
    char city[MAX_CITY_LENGTH]; // Name of the city
    char parentCity[MAX_CITY_LENGTH]; // Name of parent city in the path just before this city
    double totalLength; // Total length from the origin to the city
    struct node *next; // Pointer to the next node
}node;

/* Structure of a node for heuristic values
 * When heuristic values are provided, one node for a city
 * will be allocated to store the city's name and heuristic value.
 */
typedef struct heuristicNode
{
    char city[MAX_CITY_LENGTH]; // Name of the city
    double heuristicValue; // Heuristic value for the city
    struct heuristicNode* next; // Pointer to next node
}heuristicNode;

/* Function to return heuristic value for a city
 * Parameter1: inputHeuristicListHead: Head of linked list containing heuristic city nodes
 * Parameter2: city: string for city whose heuristic value is to be found and returned
 */
double getHeuristicValue(heuristicNode *inputHeuristicListHead, char *city)
{
    // Scan the list until the city is found, and return the heuristic value
    heuristicNode *curNode = inputHeuristicListHead;
    while (curNode != NULL)
    {
        if (strcasecmp(curNode->city, city) == 0)
        {
            // Match found, return the heuristic value
            return curNode->heuristicValue;
        }
        curNode = curNode->next;
    }
    return 0; // Heuristic value not provided in input, return 0
}

/* Function to insert a node into a priority queue
 * Priority queue is implemented as a singly linked list
 * Parameter1: head: Pointer to the head of the priority queue
 * Parameter2: nodeToInsert: The node to be inserted into the priority queue
 * Parameter3: inputHeuristicListHead: Head of linked list containing heuristic city nodes
 *             for uninformed search, no heuristic nodes are provided, so this will be NULL
 * Priority is total length, and the node having minimum total length
 * has the highest priority and will be popped first. So this priority
 * queue will be sorted by nodes in increasing order of total length
 */
void insert(node** head, node* nodeToInsert, heuristicNode *inputHeuristicListHead)
{
    // If heuristic inputs are to be used, add heuristic value before inserting to priority queue
    // This is for informed search using a-star search
    if (inputHeuristicListHead != NULL)
    {
        nodeToInsert->totalLength += getHeuristicValue(inputHeuristicListHead, nodeToInsert->city);
    }

    // If the queue is empty OR
    // If the node has total length less than the total length of head,
    // the node will be inserted at head of the queue and will become the new head
    if (((*head) == NULL) || (nodeToInsert->totalLength < (*head)->totalLength))
    {
        nodeToInsert->next = *head;
        (*head) = nodeToInsert;
    }
    else
    {
        // Node is not going to be the head of the queue, find the correct position
        // Scan the priority queue by comparing the total length each time to find
        // the right position
        node* curNode = (*head);
        while ((curNode->next != NULL) && (curNode->next->totalLength < nodeToInsert->totalLength))
        {
            curNode = curNode->next;
        }
        // The node will be inserted after the curNode
        // It is possible that the curNode is the last ndoe in the list, in that case
        // add the node at the end of the list
        nodeToInsert->next = curNode->next;
        curNode->next = nodeToInsert;
    }
}

/* Function to pop a node from a priority queue
 * Priority queue is implemented as a singly linked list
 * Parameter1: head: Pointer to the head of the priority queue
 * Parameter2: inputHeuristicListHead: Head of linked list containing heuristic city nodes
 *             for uninformed search, no heuristic nodes are provided, so this will be NULL
 * The function removes the node at the head of the priority queue
 * and returns it. The head of the queue is updated after removal
 * of node.
 */
node* pop(node** head, heuristicNode* inputHeuristicListHead)
{
    node* temp = *head;
    (*head) = (*head)->next;

    // If heuristic inputs are to be used, subtract heuristic value before popping from priority queue
    // This is for informed search using a-star search
    if (inputHeuristicListHead != NULL)
    {
        temp->totalLength -= getHeuristicValue(inputHeuristicListHead, temp->city);
    }

    return temp;
}

/* Function to check the linked list containing nodes of visited cities
 * to see if a given city is in the list
 * Parameter1: head: Head of the linked list
 * Parameter2: city: String for city to be used to see if the city is present in the list
 * The function will return true if the city is present in the list
 * The function will return false if the city is not present in the list
 */
bool isVisited(node *head, char *city)
{
    node *curNode = head;
    while(curNode != NULL)
    {
        // Compare the node's city name with the parameter
        if (strcasecmp(curNode->city, city) == 0)
        {
            // City is present in the list, return true
            return true;
        }
        curNode = curNode->next;
    }
    // Reached the end of list without finding a match, city not found, so return false
    return false;
}

/* Implementation of uninformed and informed search
 * Uninformed search is performed using Uniform Cost Search algorithm
 * Informed search is performed using A-star algorithm
 * Implemented using singly linked list based priority queues
 * Parameter1: origin: String for origin city
 * Parameter2: destination: String for destination city
 * Parameter3: inputEdgeListHead: Head of linked list containing edges in the graph
 * Parameter4: inputHeuristicListHead: Head of linked list containing heuristic city nodes
 *             For uninformed search, no heuristic nodes are provided, so this will be NULL
 * Implementation assumes undirected graph
 */
void uninformed_and_informed_search(char *origin, char *destination, edge *inputEdgeListHead, heuristicNode *inputHeuristicListHead)
{
    // Create an empty priority queue
    node* qHead = NULL;
    // Pointer for each new node
    node *newNode = NULL;
    // Create an empty list of visited nodes
    node* visitedListHead = NULL;
    // Initialize outputs
    int numNodesPopped = 0;
    int numNodesExpanded = 0;
    int numNodesGenerated = 0;
    bool destinationReached = false;

    // Create a priority queue node for the origin, insert it to the head
    newNode = (node *)malloc(sizeof(node));
    numMallocs++;
    strcpy(newNode->city, origin);
    newNode->totalLength = 0; // total length for origin is 0
    numNodesGenerated++;
    insert(&qHead, newNode, inputHeuristicListHead);

    // Continue to pop until either
    // 1. The queue is empty (path to destination does not exist) OR
    // 2. The destination city's node is popped from the queue
    while (qHead != NULL)
    {
        // Pop from the queue
        node* poppedNode = pop(&qHead, inputHeuristicListHead);
        // Increment count for nodes popped
        numNodesPopped++;

        // If the node popped is the destination city, we have
        // found the shortest length to the city, so break and end here.
        if(strcasecmp(poppedNode->city, destination) == 0)
        {
            // Reached destination. Add the node to visited node list, and break
            poppedNode->next = visitedListHead;
            visitedListHead = poppedNode;
            destinationReached = true;
            break;
        }

        // Expand the node only if the node is not in the visited list
        // So first check if the node is in visited list
        if (isVisited(visitedListHead, poppedNode->city) == false)
        {
            // Expand the node
            numNodesExpanded++;
            // Traverse all edges in the graph (edge linked list) to find out edges containing this popped node's city
            edge *curEdge = inputEdgeListHead;
            while (curEdge != NULL)
            {
                bool edgeHasCity = false;
                char connectingCity[MAX_CITY_LENGTH];
                // For each edge in the list, check if the city in popped node
                // is present as origin city or destination city in the edge.
                if (strcasecmp(curEdge->source, poppedNode->city) == 0)
                {
                    edgeHasCity = true;
                    strcpy(connectingCity, curEdge->destination);
                }
                else if (strcasecmp(curEdge->destination, poppedNode->city) == 0)
                {
                    edgeHasCity = true;
                    strcpy(connectingCity, curEdge->source);
                }
                if (edgeHasCity == true)
                {
                    // Egde in the list has the city connecting popped node's city.
                    // Add the connecting city only if it is not already visited.
                    // Check if the connecting city is already visited
                    if (isVisited(visitedListHead, connectingCity) == false)
                    {
                        // Connecting city is not already visited
                        // Create a priority queue node and insert into the queue
                        newNode = (node *)malloc(sizeof(node));
                        numMallocs++;
                        strcpy(newNode->city, connectingCity);
                        // The node's parent city is the city in the popped node
                        strcpy(newNode->parentCity, poppedNode->city);
                        // Store the total length from origin to the city
                        newNode->totalLength = curEdge->length + poppedNode->totalLength;
                        insert(&qHead, newNode, inputHeuristicListHead);
                        numNodesGenerated++;
                    }
                }
                curEdge = curEdge->next;
            }
            // We have scanned all the edges in the graph
            // Move the popped node to head of visited list
            if (visitedListHead == NULL)
            {
                // Visited list is empty
                visitedListHead = poppedNode;
                poppedNode->next = NULL;
            }
            else
            {
                // Visited list is not empty
                poppedNode->next = visitedListHead;
                visitedListHead = poppedNode;
            }
        }
        else
        {
            // Popped node is already visited. It won't be used anymore. So free it
            free(poppedNode);
            numFreed++;
        }
    }

    // Now the visited list will have nodes visited in
    // reverse order. That is, the city first visited will
    // be at the end of the list. And the city last visited
    // will be at the head of the list
    // If shortest path exists, this list will have every
    // node in the shortest path.
    node *curNode = visitedListHead;
    node *prevNode = NULL;

    // Print outputs
    printf("Nodes Popped: %d\n",numNodesPopped);
    printf("Nodes Expanded: %d\n",numNodesExpanded);
    printf("Nodes Generated: %d\n",numNodesGenerated);

    // Create a new empty list to store only the shortest path nodes
    // from origin to destination from head to tail in order
    // We will move nodes from visited list to the shortest path list
    // one by one
    node *shortestPathListHead = NULL;
    if (destinationReached == true)
    {
        // Path exists to destination, print shortest path found up to two decimal places
        printf("Distance: %.2f km\n",visitedListHead->totalLength);

        // Use the parent city to trace back from destination to origin
        char searchCity[MAX_CITY_LENGTH];
        strcpy(searchCity, destination);
        while(curNode != NULL)
        {
            // Check if the node in the list is the city we are looking for
            if (strcasecmp(curNode->city, searchCity) == 0)
            {
                // Current search city node found
                // Remove it from visited list and move to head of shortestPathList
                node *nodeToRemove = curNode;
                if (nodeToRemove == visitedListHead)
                {
                    // Node to remove is visited list's head
                    visitedListHead = visitedListHead->next;
                    curNode = visitedListHead;
                }
                else
                {
                    // Node to remove is not the visited list's head
                    prevNode->next = curNode->next;
                    curNode = curNode->next;
                }
                // Add removed node to the head shortest path list
                if (shortestPathListHead == NULL)
                {
                    // Shortest path list is empty
                    shortestPathListHead = nodeToRemove;
                    nodeToRemove->next = NULL;
                }
                else
                {
                    // Shortest path list is not empty
                    nodeToRemove->next = shortestPathListHead;
                    shortestPathListHead = nodeToRemove;
                }
                // Now we want to find the current city's parent city in the list, so update the search city
                strcpy(searchCity, nodeToRemove->parentCity);
            }
            else
            {
                // The node is not in the shortest path, so move to next node in visited list
                prevNode = curNode;
                curNode = curNode->next;
            }
        }
        // Now the shortest path list contains nodes in shortest path from origin to destination
        // And the total length in each node indicates the total length in the path up to the node
        curNode = shortestPathListHead;
        printf("Route:\n");
        while(curNode->next != NULL)
        {
            // Print in expected format the source destination and length up to two decimal places
            printf("%s to %s, %.2f km\n",curNode->city, curNode->next->city, curNode->next->totalLength - curNode->totalLength);
            curNode = curNode->next;
        }
    }
    else
    {
        // Path is not present, print infinity as expected output length
        printf("Distance: infinity\nRoute:\nNone");
    }

    // All nodes we allocated will be split into possibly three lists:
    // 1. visited node list
    // 2. priority queue
    // 3. shortest path list
    // Free all nodes from all the lists

    // 1. Free nodes from visited node list
    curNode = visitedListHead;
    while(curNode != NULL)
    {
        node *temp = curNode;
        curNode = curNode->next;
        free(temp);
        numFreed++;
    }
    // 2. Pop and free all nodes from priority queue
    while(qHead != NULL)
    {
        node *temp = pop(&qHead, NULL);
        free(temp);
        numFreed++;
    }
    // 3. Free nodes from shortest path list
    curNode = shortestPathListHead;
    while(curNode != NULL)
    {
        node *temp = curNode;
        curNode = curNode->next;
        free(temp);
        numFreed++;
    }
}

/* Main function
 * When executed from command line, format for command line arguments is
 * for uninformed search: <program_name> <input_file> <source_city> <destination_city>
 * for informed search: <program_name> <input_file.txt> <source_city> <destination_city> <heuristic_file_for_destination.txt>
 */
int main(int argc, char* argv[])
{
    // Get command line arguments as inputs
    char* inputFileName = argv[1]; // first argument is input file for edges
    char* origin = argv[2]; // second argument is source city
    char* dst = argv[3]; // third argument is destination city
    char* heuristifFileName = NULL; // Initially point to NULL

    // Open the input file in read mode
    FILE* inputFile = fopen(inputFileName, "r");
    // Assume one line has maximum of 1000 characters
    char line[1000];

    // Create a linked list to store every edge in input
    // Start with an empty list
    edge *inputEdgeListHead = NULL;
    edge *inputEdgeListTail = NULL;

    // Get one line at a time, and create an edge
    while (fgets(line, sizeof(line), inputFile))
    {
        // Repeat until "END OF INPUT" line is seen in file
        // "END OF INPUT" is total length of 12 characters, so compare first 12 characters
        if (strncmp(line, "END OF INPUT", 12) == 0)
        {
            break;
        }
        
        // Valid edge found in file, dynamically allocate an edge to add to list
        edge *newEdge = (edge *)malloc(sizeof(edge));
        numMallocs++;
        // Add the edge to the linked list
        if (inputEdgeListHead == NULL)
        {
            // List is empty, so make the new edge the head of list
            inputEdgeListHead = newEdge;
            inputEdgeListTail = inputEdgeListHead;
            newEdge->next = NULL;
        }
        else
        {
            // List is not empty, add the new edge to tail of the list
            inputEdgeListTail->next = newEdge;
            inputEdgeListTail = newEdge;
            newEdge->next = NULL;
        }
        // Scan the line, and get the source city, destination city and length from
        // the line scanned and store in the edge created
        sscanf(line, "%s %s %lf", newEdge->source, newEdge->destination, &(newEdge->length));
    }
    // File scan complete
    fclose(inputFile);

    // Create a-star related parameters
    heuristicNode *inputHeuristicListHead = NULL;
    heuristicNode *inputHeuristicListTail = NULL;
    if (argc == 5)
    {
        // Five arguments are provided, so the fifth one is a heuristic file
        heuristifFileName = argv[4];

        // Open the heuristic input file in read mode
        inputFile = fopen(heuristifFileName, "r");

        // Get one line at a time, and create an edge
        while (fgets(line, sizeof(line), inputFile))
        {
            // Repeat until "END OF INPUT" line is seen in file
            // "END OF END OF INPUT" is total length of 12 characters, so compare first 12 characters
            if (strncmp(line, "END OF INPUT", 12) == 0)
            {
                break;
            }
            
            // Valid heuristic value found in file, dynamically allocate a node to add to list
            heuristicNode *newNode = (heuristicNode *)malloc(sizeof(heuristicNode));
            numMallocs++;
            // Add the node to the linked list
            if (inputHeuristicListHead == NULL)
            {
                // List is empty, so make the new edge the head of list
                inputHeuristicListHead = newNode;
                inputHeuristicListTail = inputHeuristicListHead;
                newNode->next = NULL;
            }
            else
            {
                // List is not empty, add the new edge to tail of the list
                inputHeuristicListTail->next = newNode;
                inputHeuristicListTail = newNode;
                newNode->next = NULL;
            }
            // Scan the line, and get the source city, destination city and length from
            // the line scanned and store in the edge created
            sscanf(line, "%s %lf", newNode->city, &(newNode->heuristicValue));
        }
        // File scan complete
        fclose(inputFile);
    }

    // Perform search
    uninformed_and_informed_search(origin, dst, inputEdgeListHead, inputHeuristicListHead);

    // Finally, free all edges previously allocated
    edge *curEdge = inputEdgeListHead;
    while(curEdge != NULL)
    {
        edge *edgeToFree = curEdge;
        curEdge = curEdge->next;
        free(edgeToFree);
        numFreed++;
    }
    // Free all the heuristic nodes if we allocated any
    heuristicNode *curNode = inputHeuristicListHead;
    while(curNode != NULL)
    {
        heuristicNode *nodeToFree = curNode;
        curNode = curNode->next;
        free(nodeToFree);
        numFreed++;
    }
    // Enable this to check if all memories allocated are freed
    // printf("\nNum mallocs: %d num frees: %d",numMallocs, numFreed);
    return 0;
}