
									README


PROGRAMMING LANGUAGE: C programming

CODE STRUCTURE:


 * The program performs uninformed and informed search for a given set of inputs to determine shortest path from an origin city to a destination city.
 * Uninformed search is done using Uniform Cost Search algorithm using priority queues.
 * Informed search is done using A-star algorithm and takes heuristic inputs.
 * The program uses number of command line arguments provided to choose between uninformed search and informed search to perform. If no heuristic input file               is provided,the program performs uninformed search using three arguments provided from command line.
 * When a heuristic input file is provided as fourth argument, the program performs informed cost search.

I keep track of the visted nodes, not visiting them if they are already visted, so i got the optimal solution for noped pooped, generated and expanded
Nodes popped are added to the head of the visited list each time if they are not in the visited list already.

Fringes/data structures:

		1)Structure of an edge. An edge has a source city, a destination, city, and the length (in km) between the source and destination cities.
		2)Structure of a node that will be inserted and popped from the priority queue.
		3)Structure of a node for heuristic values when heuristic values are provided, one node for a city will be allocated to store the city's 		 name and heuristic value.

For the above 3 structures, singly linked list is used.

FUNCTIONS  Explained:

double getHeuristicValue(heuristicNode *inputHeuristicListHead, char *city)
{
	/* Function to return heuristic value for a city 
	Parameter1: inputHeuristicListHead: Head of the linked list containing heuristic city nodes
 	Parameter2: city: string for city whose heuristic value is to be found and returned
 	*/
}

void insert(node** head, node* nodeToInsert, heuristicNode *inputHeuristicListHead)
{
	/* Function to insert a node into a priority queue 
	Priority queue 	is implemented as a singly linked list
 	Parameter1: head: Pointer to the head of the priority queue
 	Parameter2: nodeToInsert: The node to be inserted into the priority queue
 	Parameter3: inputHeuristicListHead: Head of linked list containing heuristic city nodes for uninformed search, no heuristic nodes are provided, so 	            this will be NULL
 	* Priority is total length, and the node having minimum total length has the highest priority and will be popped first. So this priority queue will                    	  be sorted by nodes in increasing order of total length
 	*/
}

node* pop(node** head, heuristicNode* inputHeuristicListHead)
{
	/* Function to pop a node from a priority queue
 	 Priority queue is implemented as a singly linked list
 	 Parameter1: head: Pointer to the head of the priority queue
 	 Parameter2: inputHeuristicListHead: Head of linked list containing heuristic city nodes for uninformed search, no heuristic nodes are 	 provided,     		     so this will be NULL
 	* The function removes the node at the head of the priority queue and returns it. The head of the queue is updated after removal of node.
        */
}

bool isVisited(node *head, char *city)
{
	/* Function to check the linked list containing nodes of visited cities to see if a given city is in the list
 	Parameter1: head: Head of the linked list
 	Parameter2: city: String for city to be used to see if the city is present in the list
 	* The function will return true if the city is present in the list
 	* The function will return false if the city is not present in the list
 	*/
}

void uninformed_and_informed_search(char *origin, char *destination, edge *inputEdgeListHead, heuristicNode *inputHeuristicListHead)
{
	/* Implementation of uninformed and informed search
 	* Uninformed search is performed using Uniform Cost Search algorithm
 	* Informed search is performed using A-star algorithm
 	* Implemented using singly linked list based priority queues
 	* Parameter1: origin: String for origin city
 	* Parameter2: destination: String for destination city
 	* Parameter3: inputEdgeListHead: Head of linked list containing edges in the graph
 	* Parameter4: inputHeuristicListHead: Head of linked list containing heuristic city nodes
 	* For uninformed search, no heuristic nodes are provided, so this will be NULL
 	* Implementation assumes an undirected graph
 	*/
}

		

CODE RUN:  (please follow the one which works on your system)

a)extract the ZIP folder, consider the extracted folder for execution 
b)place the input files in the extracted folder,same path where the ".c" is present.
c)Since the Code is in C programming make sure the system has gcc compiler, if not please install it.

On Linux:

	a)Open Ubuntu and give the below-mentioned command to check if the gcc is installed
	       gcc --version(enter)
          if there is no gcc, please install the compiler, it is essential to run the code (skip to 'b' if u have gcc already)
          Commands to install gcc on Ubuntu :  https://phoenixnap.com/kb/install-gcc-ubuntu (open the link in google for the step by step                       					                                                     installation of gcc)
		

	b)Open Ubuntu and give the following command and hit enter, it will open the folder directory
		           cd path_to_src_file   
		Example  : cd /home/ganga/1002163448_assmt1/

	c)give the following command in the command prompt and hit enter, this will generate the executable program named find_route 
              
                gcc -o find_route find_route.c

	d))run the program as below to perform uninformed search

               ./find_route input_file.txt source_city destination_city
               Example is:
		./find_route input1.txt Bremen Kassel

	e)run the program as below to perform informed search

              ./find_route input_file.txt source_city destination_city heuristic_input_file.txt
               Example is:
              ./find_route input1.txt Bremen Kassel h_kassel.txt


On Windows command prompt:
	
	a)Open command prompt and give the below-mentioned command to check if the gcc is installed
	       gcc --version(enter)
          if there is no gcc, please install the compiler. 
	  Follow the link to install gcc https://www.codingninjas.com/studio/library/gcc-compiler-for-windows 

	b)give the following command and hit enter, it will open the folder directory
		           cd path_to_src_file   
		Example  : cd C:\Users\ganga\Desktop\1002163448_assmt1	
           

	c)give the following command in the command prompt and hit enter, this will generate the executable program named find_route 
              
                gcc -o find_route find_route.c

	d)run the program as below to perform uninformed search

              .\find_route input_file.txt source_city destination_city
               Example is:
              .\find_route input1.txt Bremen Kassel

       e)run the program as below to perform informed search

              .\find_route input_file.txt source_city destination_city heuristic_input_file.txt
               Example is:
              .\find_route input1.txt Bremen Kassel h_kassel.txt

On Windows Powershell:

	a)Open Powershell and give the below-mentioned command to check if the gcc is installed
	       gcc --version(enter)
          if there is no gcc, please install the compiler. 
	  Follow the link to install gcc https://www.codingninjas.com/studio/library/gcc-compiler-for-windows 

	b)give the following command and hit enter, it will open the folder directory
			   $env:Path += ";C:\MinGW\bin"     (command to copy the gcc folder path to your power shell) hit enter

		           cd path_to_src_file   
		Example  : cd C:\Users\ganga\Desktop\1002163448_assmt1

	c)give the following command in the command prompt and hit enter, this will generate the executable program named find_route 
              
                gcc -o find_route find_route.c

	d)run the program as below to perform uninformed search

              .\find_route input_file.txt source_city destination_city
               Example is:
              .\find_route input1.txt Bremen Kassel

       e)run the program as below to perform informed search

              .\find_route input_file.txt source_city destination_city heuristic_input_file.txt
               Example is:
              .\find_route input1.txt Bremen Kassel h_kassel.txt

	


			
		
